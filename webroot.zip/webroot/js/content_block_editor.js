function switchEditor() {
    if (contentTypeSelect.value === 'html') {
        // When HTML is selected, initialise wysiwyg editor
        ClassicEditor
            .create(document.querySelector('textarea[name=content_value]'))
            .then(editor => {
                ckeditorInstance = editor; // So we can reuse this instance later
            })
            .catch(error => {
                console.error(error);
            });
    } else {
        // Otherwise, destroy the editor instance
        if (ckeditorInstance) {
            ckeditorInstance.destroy();
            ckeditorInstance = undefined;
        }
    }
}

let ckeditorInstance;

// Show the correct control when content_type select changes
let contentTypeSelect = document.getElementById('content-type');
contentTypeSelect.addEventListener("change", switchEditor);
switchEditor();
